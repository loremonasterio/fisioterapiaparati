package com.telefonica.fisioterapiaparati;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.internal.BottomNavigationMenuView;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;


import org.json.JSONException;

import java.util.ArrayList;
import java.util.StringTokenizer;


public class MainActivity extends AppCompatActivity {



    private ArrayList<Video> videos = new ArrayList<Video>();
    private String[] tituloSinInternet = {"Se necesita conexión a internet para acceder a los vídeos"};
    private String[] fotoSinInternet = {"https://static.parastorage.com/services/santa/1.2207.10/static/images/video/not-found.png"};
    private ListView lista;
    private String cadenaVideos = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainactivity_content);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavView);
        BotonNavigationViewHelper.disableShiftMode(bottomNavigationView);
        Menu menu =bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_videos:

                    break;
                    case R.id.action_salud:
                        Intent intent = new Intent(MainActivity.this, Patologias.class);
                        startActivity(intent);
                    break;
                    case R.id.action_agenda:
                        Intent intent2 = new Intent(MainActivity.this, Calendario.class);
                        startActivity(intent2);
                    break;
                    case R.id.action_contacto:
                        Intent intent3 = new Intent(MainActivity.this, Contacto.class);
                        startActivity(intent3);
                    break;
                }


                return false;
            }
        });

        /*bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.action_videos:

                        break;
                    case R.id.action_salud:
                        Intent Second= new Intent(MainActivity.this, Patologias.class);
                        startActivity(Second);
                        BottomNavigationView bottomNavigationView = (BottomNavigationView)findViewById(R.id.botonNavegacion);
                        BotonNavigationViewHelper.disableShiftMode(bottomNavigationView);
                        break;
                    case R.id.action_agenda:
                        Intent third= new Intent(MainActivity.this, Calendario.class);
                        startActivity(third);
                        break;
                    case R.id.action_contacto:
                        Intent four= new Intent(MainActivity.this, Contacto.class);
                        startActivity(four);
                        break;
                }
                return true;
            }
        });
*/
        lista=(ListView)findViewById(R.id.listaTitulos);
        SharedPreferences sp = this.getSharedPreferences("preferencias", Context.MODE_PRIVATE);
        cadenaVideos = sp.getString("CadenaVideos","");
        try {
            anadirVideos(cadenaVideos);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        generarLista(videos);

        if(!isNetworkAvailable()) {
            CustomList adapter = new CustomList(MainActivity.this, tituloSinInternet, fotoSinInternet);
            lista.setAdapter(adapter);
        }

    }

    public void onResume(){
        super.onResume();
    }

    public void generarLista(ArrayList<Video> videos){
        String[] titulos = new String[videos.size()];
        String[] fotos = new String[videos.size()];
        final String[] videoIDS = new String[videos.size()];
        for (int i=0; i<videos.size(); i++){
            titulos[i] = videos.get(i).getTitulo();
            fotos[i] = videos.get(i).getImagen();
            videoIDS[i] = videos.get(i).getVideoID();
        }
        CustomList adapter = new CustomList(MainActivity.this, titulos, fotos);
        lista.setAdapter(adapter);
        lista.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent,
                                            View view, int position, long id) {
                        Intent intent = null;
                        try {
                            Context context = getApplicationContext();
                            context.getPackageManager().getPackageInfo("com.google.android.youtube", 0);
                            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube://" + videoIDS[position]));
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        } catch (Exception e) {
                            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v="+videoIDS[position]));
                        }
                    startActivity(intent);
                    }
                });
    }
    public void anadirVideos(String cadena) throws JSONException {
        StringTokenizer st = new StringTokenizer(cadena,"|");
        while(st.hasMoreElements()){
            Video video = new Video(st.nextElement().toString());
            videos.add(video);
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null;
    }




}
